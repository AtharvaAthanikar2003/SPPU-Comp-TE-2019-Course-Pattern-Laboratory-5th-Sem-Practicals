
public class arglist {
	String argname;
	arglist(String argument) {
		// TODO Auto-generated constructor stub
		this.argname=argument;
	}
}
