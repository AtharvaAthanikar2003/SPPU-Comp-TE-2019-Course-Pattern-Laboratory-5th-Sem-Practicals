
public class mdt {
String stmnt;
public mdt() {
	stmnt="";
    }
}
