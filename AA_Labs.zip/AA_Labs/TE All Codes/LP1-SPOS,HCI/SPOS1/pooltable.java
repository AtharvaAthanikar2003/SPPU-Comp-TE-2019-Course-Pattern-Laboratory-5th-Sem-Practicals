
public class pooltable {
int first,total_literals;
public pooltable(int f, int l) {
	this.first=f;
	this.total_literals=l;
	}
}
